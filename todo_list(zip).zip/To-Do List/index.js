import express from "express";
import bodyParser from "body-parser";
let app=express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

const list=[];

app.get("/",function(req,res){

res.render("index.ejs");
});
app.get("/",function(req,res){

res.render("list.ejs");
});

app.post("/",function(req,res){
  const item=req.body.name;
   console.log(item);
    list.push(item);
    console.log(list);

    res.render("list.ejs",{List:list});

});

app.listen(3000,function(req,res){
  console.log("listening on port 3000");
});
